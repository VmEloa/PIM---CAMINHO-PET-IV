﻿using Microsoft.AspNetCore.Mvc;
using CaminhoPet_Sistema.Data;
using CaminhoPet_Sistema.Models;

namespace CaminhoPet_Sistema.Controllers
{
    public class AnimalPerdidoController : Controller
    {
        private readonly AppDbContext _context;

        public AnimalPerdidoController(AppDbContext context)
        {
            _context = context;
        }

   
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Index(string nome, string tipo, string descricao, string localPerdido, string dataPerdido, IFormFile foto)
        {
            string nomeArquivo = "";

            // salvar imagem
            if (foto != null && foto.Length > 0)
            {
                string pasta = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot/img");

                nomeArquivo = Guid.NewGuid().ToString() + Path.GetExtension(foto.FileName);

                string caminho = Path.Combine(pasta, nomeArquivo);

                using (var stream = new FileStream(caminho, FileMode.Create))
                {
                    foto.CopyTo(stream);
                }
            }

            //  cria o objeto
            var animalPerdido = new AnimalPerdido
            {
                Nome = nome,
                Tipo = tipo,
                Descricao = descricao,
                LocalPerdido = localPerdido,
                DataPerdido = dataPerdido,
                Foto = string.IsNullOrEmpty(nomeArquivo) ? "" : "/img/" + nomeArquivo
            };

            //  Salvando as informções no banco de dados 
            _context.AnimaisPerdidos.Add(animalPerdido);
            _context.SaveChanges();

            TempData["Msg"] = "PET cadastrado com sucesso!";

            return RedirectToAction("Opções", "Home");
        }


        // cria uma lista dos animais cadastrados, na tela opções 
        public IActionResult Opcoes()
        {
            var pets = _context.AnimaisPerdidos.ToList();
            return View(pets);
        }
    }
}

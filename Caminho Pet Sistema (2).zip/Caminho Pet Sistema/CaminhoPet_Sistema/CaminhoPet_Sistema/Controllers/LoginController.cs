﻿using Microsoft.AspNetCore.Mvc;
using CaminhoPet_Sistema.Data;
using System.Linq;

public class LoginController : Controller
{
    private readonly AppDbContext _context;

    public LoginController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        return View();
    }

    // Nesse metodo o sistema irá procurar no banco de dados um usuário
    // que tenha o mesmo email e senha informados 

    // para receber os dados
    [HttpPost] 
    public IActionResult Index(string email, string senha)
    {
        var usuario = _context.Usuarios
            .FirstOrDefault(u => u.Email == email && u.Senha == senha);

        if (usuario != null)
        {
            // Login correto -  vai para opções
            return RedirectToAction("Opções", "Home");
        }

        // para caso o Login dê errado 
        TempData["Erro"] = "Email ou senha inválidos";
        return RedirectToAction("Index", "Home");
    }
}
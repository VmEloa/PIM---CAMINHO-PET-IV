using System.Diagnostics;
using CaminhoPet_Sistema.Models;
using CaminhoPet_Sistema.Data;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace CaminhoPet_Sistema.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;
        private readonly HttpClient _httpClient;

        public HomeController(
            ILogger<HomeController> logger,
            AppDbContext context,
            IHttpClientFactory httpClientFactory)
        {
            _logger = logger;
            _context = context;
            _httpClient = httpClientFactory.CreateClient();
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Index(string usuario, string senha)
        {
            return RedirectToAction("Op��es");
        }

        public IActionResult Cadastro()
        {
            return View();
        }

        public IActionResult CadastroPerdido()
        {
            return View();
        }

        public IActionResult Perfil()
        {
            return View();
        }

        public IActionResult Op��es()
        {
            return View();
        }

        public async Task<IActionResult> ConhecaPets()
        {
            var pets = new List<PetViewModel>();

            // Busca a lista de ra�as diretamente na API
            var urlRacas = "https://dog.ceo/api/breeds/list/all";

            var respostaRacas = await _httpClient.GetAsync(urlRacas);

            if (respostaRacas.IsSuccessStatusCode)
            {
                var jsonRacas = await respostaRacas.Content.ReadAsStringAsync();

                var dadosRacas = JsonSerializer.Deserialize<DogApiResponse>(
                    jsonRacas,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    });

                // Pega as primeiras 16 ra�as disponibilizadas pela API
                var racas = dadosRacas?.Message.Keys.Take(16).ToList();

                if (racas != null)
                {
                    foreach (var raca in racas)
                    {
                        var urlImagem =
                            $"https://dog.ceo/api/breed/{raca}/images/random";

                        var respostaImagem =
                            await _httpClient.GetAsync(urlImagem);

                        if (respostaImagem.IsSuccessStatusCode)
                        {
                            var jsonImagem =
                                await respostaImagem.Content.ReadAsStringAsync();

                            var dadosImagem =
                                JsonSerializer.Deserialize<DogImageResponse>(
                                    jsonImagem,
                                    new JsonSerializerOptions
                                    {
                                        PropertyNameCaseInsensitive = true
                                    });

                            pets.Add(new PetViewModel
                            {
                                Nome = raca,
                                Imagem = dadosImagem?.Message
                            });
                        }
                    }
                }
            }

            return View(pets);
        }


        [HttpGet]
        public async Task<IActionResult> BuscarRaca(string nome)
        {
            if (string.IsNullOrWhiteSpace(nome))
            {
                return Json(null);
            }

            nome = nome.Trim().ToLower();

            var url = $"https://dog.ceo/api/breed/{nome}/images/random";

            var resposta = await _httpClient.GetAsync(url);

            if (!resposta.IsSuccessStatusCode)
            {
                return Json(null);
            }

            var json = await resposta.Content.ReadAsStringAsync();

            var dados = JsonSerializer.Deserialize<DogImageResponse>(
                json,
                new JsonSerializerOptions
                {
                    PropertyNameCaseInsensitive = true
                });

            if (dados == null || string.IsNullOrEmpty(dados.Message))
            {
                return Json(null);
            }

            var pet = new PetViewModel
            {
                Nome = nome,
                Imagem = dados.Message
            };

            return Json(pet);
        }
    }
}
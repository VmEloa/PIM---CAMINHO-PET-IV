﻿using CaminhoPet_Sistema.Data;
using CaminhoPet_Sistema.Models;
using Microsoft.AspNetCore.Mvc;

namespace CaminhoPet_Sistema.Controllers
{
    public class OpcoesController : Controller
    {
        private readonly AppDbContext _context;

        public OpcoesController(AppDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var pets = _context.AnimaisPerdidos.ToList();
            return View(pets);
        }
    }
}
﻿using CaminhoPet_Sistema.Models;
using Microsoft.AspNetCore.Mvc;
using CaminhoPet_Sistema.Data;
using System;

public class CadastroController : Controller
{
    private readonly AppDbContext _context;

    public CadastroController(AppDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        return View();
    }

    [HttpPost]
    public IActionResult Index(string nome, string email, string telefone, string senha)
    {

        // utilizando o try cath para tratar possiveis erros 
        try
        {
            Usuario usuario = new Usuario
            {
                Nome = nome,
                Email = email,
                Telefone = telefone,
                Senha = senha
            };

            _context.Usuarios.Add(usuario);
            _context.SaveChanges();

            // redireciona para o login
            return RedirectToAction("Index", "Home");
        }
        catch (Exception ex)
        {
            ViewBag.Msg = ex.Message;
            return View();
        }
    }
}
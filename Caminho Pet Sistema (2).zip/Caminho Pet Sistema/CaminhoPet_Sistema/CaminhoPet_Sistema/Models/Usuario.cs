﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace CaminhoPet_Sistema.Models
{


    //Criando a classe Usuario - de acordo com o banco de Dados
    public class Usuario
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Senha { get; set; }
        public string Telefone { get; set; }

        
    }
}

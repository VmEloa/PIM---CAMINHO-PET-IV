﻿using System.Globalization;

namespace CaminhoPet_Sistema.Models
{


    //Animal adoção irá herdar alguns atributos da classe Animal
    public class AnimalAdocao : Animal
    {
        public int Idade { get; set; }
        public string Porte { get; set; }
        public string Sexo { get; set; }
        public bool Vacinado { get; set; }
        public bool Castrado { get; set; }
        public string Status { get; set; }
    }
}

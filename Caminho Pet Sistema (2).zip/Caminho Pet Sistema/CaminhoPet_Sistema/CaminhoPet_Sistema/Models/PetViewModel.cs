﻿namespace CaminhoPet_Sistema.Models
{
    
    
        public class PetViewModel
        {
            public string Nome { get; set; }
            public string Imagem { get; set; }
        }
 }
﻿namespace CaminhoPet_Sistema.Models
{
    public class DogImageResponse
    {
        public string Message { get; set; }
        public string Status { get; set; }
    }
}

﻿namespace CaminhoPet_Sistema.Models
{
    public class DogApiResponse
    {
        public Dictionary<string, List<string>> Message { get; set; }
        public string Status { get; set; }

    }
}

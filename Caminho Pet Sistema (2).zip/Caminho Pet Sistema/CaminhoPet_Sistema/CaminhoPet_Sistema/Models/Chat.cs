﻿namespace CaminhoPet_Sistema.Models
{
    public class Chat
    {
        public int Id { get; set; }
        public List<Usuario>Usuarios { get; set; }

        
    }
}

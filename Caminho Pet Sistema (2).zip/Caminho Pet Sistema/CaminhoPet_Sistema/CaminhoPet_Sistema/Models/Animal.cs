﻿using System.Globalization;

namespace CaminhoPet_Sistema.Models
{
    public class Animal
    {

        public int Id { get; set; }
        public string Nome { get; set; }
        public string Tipo { get; set; }
        public string Descricao { get; set; }
        public string Foto{ get; set; } 
    }
    public class AnimalPerdido : Animal
    {
        public string LocalPerdido { get; set; }
        public string DataPerdido { get; set; }
    }
}
﻿using CaminhoPet_Sistema.Models;
using Microsoft.EntityFrameworkCore;

namespace CaminhoPet_Sistema.Data 
{
    //  representação do conexão com o banco de dados
    public class AppDbContext : DbContext
    {
        // Construtor que recebe irá receber as  config
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        // Cada DbSet vira uma tabela no banco
        // Mencionado a tabela Usuarios que existe no banco de dados
        public DbSet<Usuario> Usuarios { get; set; }

        public DbSet<Animal> Animais { get; set; }

        public DbSet<AnimalPerdido> AnimaisPerdidos { get; set; }




        // Método responsável pelas configurações extras do banco
        // Utilizando para herança, pois são tabelas separadas 

        // Necessario por conta das heranças 
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // 🔥 HERANÇA COM TABELAS SEPARADAS (TPT)

            modelBuilder.Entity<Animal>()
                .ToTable("Animais");

            modelBuilder.Entity<AnimalPerdido>()
                .ToTable("AnimaisPerdidos");

        }
    }

} 
using Microsoft.EntityFrameworkCore;
using CaminhoPet_Sistema.Data;

var builder = WebApplication.CreateBuilder(args);

// Conex�o com MySQL
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseMySQL(
        builder.Configuration.GetConnectionString("DefaultConnection")
    ));

// MVC
builder.Services.AddControllersWithViews();

// HTTP Client para consumir APIs externas
builder.Services.AddHttpClient();

var app = builder.Build();

app.UseStaticFiles();

app.UseRouting();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}"
);

app.Run();